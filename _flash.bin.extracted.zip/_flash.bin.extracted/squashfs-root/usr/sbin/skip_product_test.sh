#!/bin/sh

free_memory.sh
rm /tmp/tutk_test* -rf
tuya_daemon.sh &
