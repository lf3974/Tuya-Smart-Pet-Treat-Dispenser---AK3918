#!/bin/sh

wifi_dev=$2
#ap channel
max_chn=0
wifi_module="rtl8188fu"

#killall AP mode tool
host_pid=`pgrep hostapd`
if [ ! -z "$host_pid" ];then
    killall hostapd 
fi

dhcpd_pid=`pgrep udhcpd`
if [ ! -z "$dhcpd_pid" ];then
    killall udhcpd 
fi

wpap_pid=`pgrep wpa_passphrase`
if [ ! -z "$wpap_pid" ];then
    killall wpa_passphrase

fi

wpas_pid=`pgrep wpa_supplicant`
if [ ! -z "$wpas_pid" ];then
    killall wpa_supplicant
fi

dhcpc_pid=`pgrep udhcpc`
if [ ! -z "$dhcpc_pid" ];then
    killall udhcpc
fi

get_ap_best_chn()
{
    iwlist $wifi_dev scan

    wifi_loading_file="/tmp/wifi_chn_loading"
    cat /proc/net/$wifi_module/wlan0/best_channel | grep "The rx cnt of channel" | awk -F "= " '{print $2}' > $wifi_loading_file
    cur_cnt=0
    ret=`cat $wifi_loading_file |wc -l`
    if [ $ret -gt 0 ]; then
        while read line
        do
            let cur_cnt++
            #echo $cur_cnt
            #echo $line
            # frist get loading #
            if [ $cur_cnt -eq 1 ];then
                max_loading=$line
                max_chn=$cur_cnt
                continue
            fi

            if [ $line -ge $max_loading ];then
                max_loading=$line
                max_chn=$cur_cnt
                #echo $max_loading
                #echo $max_chn
            fi
        done < $wifi_loading_file
    fi
}

if [ "$1" = "AP" ];then
    host_conf=/etc/init.d/hostapd.conf
    udhcpd_conf=/etc/udhcpd.conf
    cp_host_conf=/tmp/hostapd.conf

    cp $host_conf $cp_host_conf
    # function #
    get_ap_best_chn
    ap_chn="s/channel=6/channel=$max_chn/g"
    sed -i $ap_chn $cp_host_conf
    ap_name="s/jiake_ap/$3/g"
    sed -i $ap_name $cp_host_conf
    hostapd -B $cp_host_conf
    ifconfig $wifi_dev 192.168.0.1
    udhcpd $udhcpd_conf

elif [ "$1" = "STA" ];then
    wpa_conf=/tmp/wpa_conf
    wep_conf=/tmp/wep_conf
    open_conf=/tmp/open_conf
    ssid_mode=$3
    wifi_encrypt_mode=1

    if [ $ssid_mode = "hide_ssid" ];then
        while true
        do
            wpas_pid=`pgrep wpa_supplicant`
            if [ ! -z "$wpas_pid" ];then
                killall wpa_supplicant
            fi

            dhcpc_pid=`pgrep udhcpc`
            if [ ! -z "$dhcpc_pid" ];then
                killall udhcpc
            fi

            case $wifi_encrypt_mode in
                0)
                    wifi_encrypt_mode=1
                    wpa_supplicant -B -i$wifi_dev -c$open_conf
                    udhcpc -i$wifi_dev -b

                    ip_addr=$(ifconfig wlan0|grep "inet addr:"|awk -F "inet addr:" '{print $2}'|awk -F ' ' '{print $1}')
                    if [ ! -z "$ip_addr" ];then
                        echo "OPEN_MODE IP Address is "$ip_addr
                        exit 0;
                    else
                        echo "OPEN_MODE ip_addr is NULL !!"
                        continue
                    fi
                    ;;
                1)
                    wifi_encrypt_mode=2
                    wpa_supplicant -B -i$wifi_dev -c$wpa_conf
                    udhcpc -i$wifi_dev -b

                    ip_addr=$(ifconfig wlan0|grep "inet addr:"|awk -F "inet addr:" '{print $2}'|awk -F ' ' '{print $1}')
                    if [ ! -z "$ip_addr" ];then
                        echo "WPA_MODE IP Address is "$ip_addr
                        exit 0;
                    else
                        echo "WPA_MODE ip_addr is NULL !!"
                        continue
                    fi
                    ;;
                2)
                    wifi_encrypt_mode=0
                    wpa_supplicant -B -i$wifi_dev -c$wep_conf
                    udhcpc -i$wifi_dev -b

                    ip_addr=$(ifconfig wlan0|grep "inet addr:"|awk -F "inet addr:" '{print $2}'|awk -F ' ' '{print $1}')
                    if [ ! -z "$ip_addr" ];then
                        echo "WEP_MODE IP Address is "$ip_addr
                        exit 0;
                    else
                        echo "WEP_MODE ip_addr is NULL !!"
                        continue
                    fi
                    ;;
            esac

        done
    else
        wpa_supplicant -B -i$wifi_dev -c$wpa_conf
        udhcpc -i$wifi_dev -b

        while true
        do
            ip_addr=$(ifconfig wlan0|grep "inet addr:"|awk -F "inet addr:" '{print $2}'|awk -F ' ' '{print $1}')
            if [ ! -z "$ip_addr" ];then
                echo "IP Address is "$ip_addr
                exit 0;
            else
                echo "ip_addr is NULL , start udhcpc !!"
                killall udhcpc
                udhcpc -i$wifi_dev -b
                continue
            fi
        done
    fi

fi
