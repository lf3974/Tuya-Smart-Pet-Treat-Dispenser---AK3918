#!/bin/sh

wifi_dev="wlan0"
led_state_flag="/mnt/config/dp_file_flag/on_light_led_file"
led_low_bright="/tmp/link_led_low_bright"
close_led_flag="/tmp/mcu_open_warning_led"
#network count
net_num=0
max_connect_cnt=3

link_led_ctrl()
{
    if [ -e $led_low_bright ];then
        val=$((1 - $1))
    else
        val=$1
    fi

    echo $val > /sys/class/leds/system_state_led/brightness
}

led_fast_blink()
{
    cnt=0
    while true
    do
        if [ $cnt -eq 8 ];then
            break
        fi
        link_led_ctrl 0
        sleep 0.5
        link_led_ctrl 1
        sleep 0.5
        let cnt++
    done
}

link_led_status()
{
    if [ -e $close_led_flag ];then
        link_led_ctrl 0
    else
        if [ -e $led_state_flag ];then
            link_led_ctrl 1
        else
            link_led_ctrl 0
        fi
    fi
}

while true 
do
    ping baidu.com -w 1
    if [ $? = 0 ];then
        echo "Network normal !!!"
        net_num=0
        link_led_status
        sleep 60
    else
        let net_num=net_num+1
    fi

    if [ $net_num -ge $max_connect_cnt ];then
        echo "Reconnect to the network !!!"
        net_num=0
        killall udhcpc
        udhcpc -i$wifi_dev -b
        led_fast_blink
        link_led_status
    fi
done
