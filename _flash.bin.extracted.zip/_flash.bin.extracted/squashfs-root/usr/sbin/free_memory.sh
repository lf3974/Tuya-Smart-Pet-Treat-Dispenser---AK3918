#!/bin/sh

echo "killall proces"
killall tutk_test_daemon.sh
killall tutk_product_test
killall tuya_daemon.sh
killall wifi_status_monitor.sh
killall ak_tuya_ipc
sleep 1
