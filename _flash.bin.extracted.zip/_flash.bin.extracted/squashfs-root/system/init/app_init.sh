#!/bin/sh

if [ -d "/mnt/config/record" ];then
    echo "exist record folder"
else
    mkdir /mnt/config/record
fi
if [ -b "/dev/mmcblk0p1" ];then
    mount /dev/mmcblk0p1 /mnt/config/record/
else
    echo "can't find sdcard"
fi

echo 0 0 0 0 > /proc/sys/kernel/printk

insmod /lib/modules/sensor_sc2232h_sc2135e.ko
insmod /lib/modules/akcamera.ko
insmod /lib/modules/ak_info_dump.ko
insmod /lib/modules/8188fu.ko
insmod /lib/modules/otg-hs.ko

start_tuya_ipc.sh &
