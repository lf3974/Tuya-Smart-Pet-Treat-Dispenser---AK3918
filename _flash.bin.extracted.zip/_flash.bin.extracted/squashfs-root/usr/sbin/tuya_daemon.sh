#!/bin/sh
while true
do
    pid=`pgrep ak_tuya_ipc`
    if [ -z "$pid" ];then
        ak_tuya_ipc &
        echo "reset ak_tuya_ipc"
        sleep 3;
    else
        sleep 1;
    fi
done
