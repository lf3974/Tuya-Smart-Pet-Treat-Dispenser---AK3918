#!/bin/sh
while true
do
    pid=`pgrep feed_watchdog`
    if [ -z "$pid" ];then
        feed_watchdog &
        echo "reset feed_watchdog"
        sleep 3;
    else
        sleep 1;
    fi
done
