#!/bin/sh

if [ "$1" = "upgrade_sys" ];then
    while true
    do
        echo 0 > /sys/class/leds/system_state_led/brightness
        sleep 0.08
        echo 1 > /sys/class/leds/system_state_led/brightness
        sleep 0.08
    done
else
    while true
    do
        for i in 0 1 2; do
            echo 0 > /sys/class/leds/system_state_led/brightness
            sleep 0.1
            echo 1 > /sys/class/leds/system_state_led/brightness
            sleep 0.1
        done
        sleep 1
    done
fi

