#!/bin/sh

led_ctrl()
{
    if [ $G_LED_BRIGHT_LEVEL = "low" ];then
        var=$((1 - $1))
    else
        val=$1
    fi
    echo $val > /sys/class/leds/system_state_led/brightness
}

while true
do
    if [ -e "/tmp/upgrade_ok" ];then
        # double blink #
        for i in 0 1
        do
            led_ctrl 0
            sleep 0.25
            led_ctrl 1
            sleep 0.25
        done
        sleep 1
    elif [ -e "/tmp/upgrade_failed" ];then
        led_ctrl 0
        sleep 1
    elif [ -e "tmp/connect_wifi_success" ];then
        led_ctrl 1
        sleep 1
    else # connecting network #
        led_ctrl 0
        sleep 0.5
        led_ctrl 1
        sleep 0.5
    fi
done
