#!/bin/sh
while true
do
    pid=`pgrep tutk_product_test`
    if [ -z "$pid" ];then
        /tmp/tutk_test/tutk_product_test &
        echo "reset tutk_product_test"
        sleep 3;
    else
        sleep 1;
    fi
done
